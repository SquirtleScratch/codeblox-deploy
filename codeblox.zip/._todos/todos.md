A lit of things to fix:

  1. Fix playwright test so that it doesn't fail in deployment.
    - && npm run test:playwright   (add to npm run dev:test)